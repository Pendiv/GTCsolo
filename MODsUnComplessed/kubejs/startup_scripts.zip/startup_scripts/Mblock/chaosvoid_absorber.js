
GTCEuStartupEvents.registry('gtceu:machine', event => {
  event.create('chaos_void_absorber', 'multiblock')
    .appearanceBlock(() => Block.getBlock('gtceu:fusion_casing'))
    .recipeType('void_absorber')

    .pattern(definition => FactoryBlockPattern.start()
      .aisle("               ", "               ","               ","               ", "               ", "      OGO      ", "               ")
      .aisle("               ", "               ","               ","               ", "      ICI      ", "    GGYYYGG    ", "      ICI      ")
      .aisle("               ", "               ","               ","               ", "    CC   CC    ", "   ELLYNYLLE   ", "    CC   CC    ")
      .aisle("               ", "               ","               ","               ", "   C       C   ", "  ENLWYNYWLNE  ", "   C       C   ")
      .aisle("               ", "               ","               ","               ", "  C         C  ", " GLLNWYNYWNLLG ", "  C         C  ")
      .aisle("      TTT      ", "      ZZZ      ","      ZZZ      ","      ZZZ      ", "  C   ZZZ   C  ", " GLWWNYNYNWWLG ", "  C         C  ")
      .aisle("     T   T     ", "     Z   Z     ","     Z   Z     ","     Z   Z     ", " I   Z   Z   I ", "OYYYYYXXXYYYYYO", " I           I ")
      .aisle("     T   T     ", "     Z   Z     ","     Z   Z     ","     Z   Z     ", " C   Z   Z   C ", "GYNNNNXXXNNNNYG", " C           C ")
      .aisle("     T   T     ", "     Z   Z     ","     Z   Z     ","     Z   Z     ", " I   Z   Z   I ", "OYYYYYXXXYYYYYO", " I           I ")
      .aisle("      TTT      ", "      ZZZ      ","      ZZZ      ","      ZZZ      ", "  C   ZZZ   C  ", " GLWWNYNYNWWLG ", "  C         C  ")
      .aisle("               ", "               ","               ","               ", "  C         C  ", " GLLNWYNYWNLLG ", "  C         C  ")
      .aisle("               ", "               ","               ","               ", "   C       C   ", "  ENLWYNYWLNE  ", "   C       C   ")
      .aisle("               ", "               ","               ","               ", "    CC   CC    ", "   ELLYNYLLE   ", "    CC   CC    ")
      .aisle("               ", "               ","               ","               ", "      ICI      ", "    GGYYYGG    ", "      ICI      ")
      .aisle("               ", "               ","               ","               ", "               ", "      OSO      ", "               ")

      .where('S', Predicates.controller(Predicates.blocks(definition.getBlock())))
      .where('C', Predicates.blocks('gtceu:fusion_casing'))
      .where('G', Predicates.blocks('gtceu:fusion_glass').or(Predicates.blocks('gtceu:fusion_casing')))
      .where('Y', Predicates.blocks('gtceu:large_scale_assembler_casing'))
      .where('X', Predicates.blocks('gtceu:high_power_casing'))
      .where('L', Predicates.blocks('gtceu:assembly_line_casing'))
      .where('W', Predicates.blocks('gtceu:sturdy_machine_casing'))
      .where('N', Predicates.heatingCoils())
      .where('Z', Predicates.blocks('gtceu:fusion_casing').or(Predicates.blocks('minecraft:bedrock')))
      .where('T', Predicates.blocks('minecraft:bedrock'))
      .where('E', Predicates.blocks('gtceu:fusion_casing').or(Predicates.abilities(PartAbility.INPUT_ENERGY).setMinGlobalLimited(1)))
      .where('I', Predicates.blocks('gtceu:fusion_casing') .or(Predicates.abilities(PartAbility.IMPORT_FLUIDS).setMinGlobalLimited(2)))
      .where('O', Predicates.blocks('gtceu:fusion_casing').or(Predicates.abilities(PartAbility.EXPORT_FLUIDS)))
      .where(' ', Predicates.any())
      .build()
    )

    .workableCasingRenderer(
      "gtceu:block/casings/fusion/fusion_casing",
      "gtceu:block/multiblock/fusion_reactor",
      false
    )
})
