StartupEvents.registry('block', event => {
  event.create('glavity_defrection_block')
    .displayName('Glavity Defrection Block')
    .material('metal') // 好みで stone / metal / glass など
    .hardness(5.0)
    .resistance(10.0)
    .requiresTool(true)
    .tagBlock('mineable/pickaxe')
    .tagBlock('needs_diamond_tool') // 不要なら消してOK
    .fullBlock(true)
    .model('kubejs:block/glavity_defrection_block')
});
