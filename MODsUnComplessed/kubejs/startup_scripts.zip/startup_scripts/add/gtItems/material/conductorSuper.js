// priority: 0

// 重要：event をクロージャで掴まない。呼び出し側から渡させる。
global.conductorSuper = function (
  event,        // ← これを追加
  name,
  components,
  color,
  iconSet,
  blastParams,
  cableParams,
  flagsArr
) {
  let m = event.create(name)
    .ingot()
    .color(color)
    .iconSet(iconSet);

  if (Array.isArray(flagsArr) && flagsArr.length) {
    m.flags.apply(m, flagsArr);
  }
  if (Array.isArray(components) && components.length) {
    m.components.apply(m, components);
  }
  if (Array.isArray(blastParams) && blastParams.length) {
    m.blastTemp.apply(m, blastParams);
  }
  if (Array.isArray(cableParams) && cableParams.length) {
    m.cableProperties.apply(m, cableParams);
  }

  return m;
};
