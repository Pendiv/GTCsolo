// priority: 5

// ==========================================================
// 【誰でも簡単一括追加リスト】
// 形式: ['ID', '記号', 色, ['配合1', '配合2', ...'配合N']]
// ※ 4番目の[配合]を省略すると、自動的に「単体素材(P120/N180)」として登録されます。
// とうぜんタイプミスはそのままクラッシュ
// ==========================================================
const CUSTOM_MATS = [
    // 1. 単体素材の例
    ['stellarium', 'St☆', 0x4169E1],
    
    // 2. 合金の例（いくつの配合もOK！）
    ['skystone_titanium', 'StTi', 0xC8A2FF, ['3x skystone', '1x titanium']],
    ['kover', 'FeNiCo', 0x33E0E0, ['1x iron', '1x nickel', '1x cobalt']], 
    ['ultra_alloy', 'Ux', 0xFF00FF, ['1x gold', '1x silver', '1x copper', '1x tin']] 
];

// 共通の生成フラグ（これがあれば一通りの工業用パーツが作れる）
const MY_COMMON_FLAGS = [
    GTMaterialFlags.GENERATE_PLATE,
    GTMaterialFlags.GENERATE_ROD,
    GTMaterialFlags.GENERATE_GEAR,
    GTMaterialFlags.GENERATE_SMALL_GEAR,
    GTMaterialFlags.GENERATE_RING,
    GTMaterialFlags.GENERATE_BOLT_SCREW,
    GTMaterialFlags.DISABLE_DECOMPOSITION
];

// ----------------------------------------------------------
// 1. 元素 (Element) の登録
// ----------------------------------------------------------
GTCEuStartupEvents.registry('gtceu:element', event => {
    CUSTOM_MATS.forEach(row => {
        const [id, symbol, color, components] = row;
        
        if (!components) {
            event.create(id)
                .protons(120)  // 固定（あとで楽するため）
                .neutrons(180) // 固定
                .symbol(symbol);
        }
    });
});

GTCEuStartupEvents.registry('gtceu:material', event => {
    CUSTOM_MATS.forEach(row => {
        const [id, symbol, color, components] = row;

        let mat = event.create(id)
            .color(color)
            .iconSet(GTMaterialIconSet.METALLIC)
            .ingot()
            .dust()
            .fluid(); 

        if (components) {
            let formatted = components.map(c => c.includes(':') ? c : 'gtceu:' + c);
            mat.components(formatted);
        } else {
            mat.element(id);
        }

        mat.flags.apply(mat, MY_COMMON_FLAGS);
    });
});