// priority: 10
//['','',,,,''],
var MY_GT_MATERIALS = [
['stellarium', 'St☆', 0x4169E1, 120, 180],
['jupitate','Ju',0x50C878,110,160,'UIV'],
['exporonium','ExPr3',0xADFF2F,169,119],
['hyperx_neutronium','Hy-χNu',0x8B8589,329,333,'UEV'],
['monel','CuNi2',0xFFE4E1,32,91,'MV'],






['bedrockium','BeDNe',0x212121,33,112,'UV']
];

// 共通フラグ
var COMMON_FLAGS = [
  GTMaterialFlags.GENERATE_PLATE,
  GTMaterialFlags.GENERATE_DENSE,
  GTMaterialFlags.GENERATE_ROD,
  GTMaterialFlags.GENERATE_LONG_ROD,
  GTMaterialFlags.GENERATE_BOLT_SCREW,
  GTMaterialFlags.GENERATE_RING,
  GTMaterialFlags.GENERATE_ROUND,
  GTMaterialFlags.GENERATE_GEAR,
  GTMaterialFlags.GENERATE_SMALL_GEAR,
  GTMaterialFlags.GENERATE_SPRING,
  GTMaterialFlags.GENERATE_FRAME,
  GTMaterialFlags.DISABLE_DECOMPOSITION
];

var WIRE_FLAGS_EXTRA = [
  GTMaterialFlags.GENERATE_FINE_WIRE
];
var VALID_TIERS = {
  ulv: true, lv: true, mv: true, hv: true, ev: true, iv: true,
  luv: true, zpm: true, uv: true, uhv: true, uev: true, uiv: true,
  uxv: true, opv: true, max: true
};

function normTier(t) {
  if (t == null) return null;
  return String(t).replace(/^\s+|\s+$/g, '').toLowerCase();
}

function hasTier(v, va, tier) {
  return !!(v && va && Object.prototype.hasOwnProperty.call(v, tier) && Object.prototype.hasOwnProperty.call(va, tier));
}

// 1) Element 登録
GTCEuStartupEvents.registry('gtceu:element', function (event) {
  for (var i = 0; i < MY_GT_MATERIALS.length; i++) {
    var row = MY_GT_MATERIALS[i];
    var id = row[0];
    var symbol = row[1];
    var p = row[3];
    var n = row[4];

    event.create(id)
      .protons(p)
      .neutrons(n)
      .symbol(symbol);
  }
});

// 2) Material 登録
GTCEuStartupEvents.registry('gtceu:material', function (event) {
  var v = global.v;
  var va = global.va;
  var conductorSuper = global.conductorSuper;

  for (var i = 0; i < MY_GT_MATERIALS.length; i++) {
    var row = MY_GT_MATERIALS[i];
    var id = row[0];
    var symbol = row[1]; // unused but kept
    var color = row[2];
    var tierRaw = row.length >= 6 ? row[5] : null;
    var tier = normTier(tierRaw);

    // tierなし → 通常アイテム型
    if (!tier) {
      var mat = event.create(id)
        .element(id)
        .color(color)
        .iconSet(GTMaterialIconSet.METALLIC)
        .ingot()
        .dust()
        .ore(1,1);
      // flags は varargs なので apply で渡す（スプレッド禁止）
      mat.flags.apply(mat, COMMON_FLAGS);

      mat.fluid();
      continue;
    }

    // tierあり → ケーブル型（条件満たさなければスキップ＋ログ）
    if (!VALID_TIERS[tier]) {
      console.info("[materials] skip cable '" + id + "': invalid tier='" + tierRaw + "' (allowed: ULV..MAX)");
      continue;
    }
    if (typeof conductorSuper !== 'function') {
      console.info("[materials] skip cable '" + id + "': global.conductorSuper missing");
      continue;
    }
    if (!hasTier(v, va, tier)) {
      var haveV = v ? Object.keys(v).join(',') : '(v missing)';
      var haveVa = va ? Object.keys(va).join(',') : '(va missing)';
      console.info("[materials] skip cable '" + id + "': tier '" + tier + "' not found in v/va. v={" + haveV + "} va={" + haveVa + "}");
      continue;
    }

    // スプレッド禁止なので concat で結合
    var wireFlags = COMMON_FLAGS.concat(WIRE_FLAGS_EXTRA);

    conductorSuper(
      event,
      id,
      null,
      color,
      GTMaterialIconSet.BRIGHT,
      [21600, 'highest', va[tier], 4000],
      [v[tier], 128, 0, true],
      wireFlags
    );
  }
});