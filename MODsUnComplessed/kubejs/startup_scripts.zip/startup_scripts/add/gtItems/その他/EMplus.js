// priority: 10
//['','',,,,''],
var MY_GT_MATERIALS = [
  
  ['singularity', '◇', 0x2E0854, 110, 160, 'UEV'],
  ['singularity_tritanium', '◇Tr', 0xB35A6B, 110, 160],
  ['singularity_bismath', '◇Bi', 0x7FC8CF, 110, 160],
  ['singularity_iron', '◇Fe', 0xE0E0E0, 110, 160],
  ['singularity_naquadah', '◇Nq', 0x4A4A4A, 110, 160],
  ['singularity_silver', '◇Ag', 0xE6E6E6, 110, 160],
  ['singularity_tungsten', '◇W', 0x3A3A38, 110, 160],
  ['singularity_osmium', '◇Os', 0x5A8FD6, 110, 160],
  ['singularity_samarium', '◇Sm', 0xB7C98A, 110, 160],
  ['quantum_singularity', '◇◇', 0xFF00FF, 1, 1],
  ['skystone_titanium_alloy', 'StTi', 0x5C6161, 110, 160],
  ['singularity_gold', '◇Au', 0xF9C834, 110, 160],
  ['singularity_diamond', '◇H', 0x33E0E0, 110, 160],
['bedrockium','BeD',0x0F0F0F,33,111],





  ['infinity', '∞', 0xFFFFFF, 120, 180, 'UXV']
];

// 共通フラグ
var COMMON_FLAGS = [
  GTMaterialFlags.GENERATE_PLATE,
  GTMaterialFlags.GENERATE_DENSE,
  GTMaterialFlags.GENERATE_ROD,
  GTMaterialFlags.GENERATE_LONG_ROD,
  GTMaterialFlags.GENERATE_BOLT_SCREW,
  GTMaterialFlags.GENERATE_RING,
  GTMaterialFlags.GENERATE_ROUND,
  GTMaterialFlags.GENERATE_GEAR,
  GTMaterialFlags.GENERATE_SMALL_GEAR,
  GTMaterialFlags.GENERATE_SPRING,
  GTMaterialFlags.GENERATE_FRAME,
  GTMaterialFlags.DISABLE_DECOMPOSITION
];

var WIRE_FLAGS_EXTRA = [
  GTMaterialFlags.GENERATE_FINE_WIRE
];
var VALID_TIERS = {
  ulv: true, lv: true, mv: true, hv: true, ev: true, iv: true,
  luv: true, zpm: true, uv: true, uhv: true, uev: true, uiv: true,
  uxv: true, opv: true, max: true
};

function normTier(t) {
  if (t == null) return null;
  return String(t).replace(/^\s+|\s+$/g, '').toLowerCase();
}

function hasTier(v, va, tier) {
  return !!(v && va && Object.prototype.hasOwnProperty.call(v, tier) && Object.prototype.hasOwnProperty.call(va, tier));
}

// 1) Element 登録
GTCEuStartupEvents.registry('gtceu:element', function (event) {
  for (var i = 0; i < MY_GT_MATERIALS.length; i++) {
    var row = MY_GT_MATERIALS[i];
    var id = row[0];
    var symbol = row[1];
    var p = row[3];
    var n = row[4];

    event.create(id)
      .protons(p)
      .neutrons(n)
      .symbol(symbol);
  }
});

// 2) Material 登録
GTCEuStartupEvents.registry('gtceu:material', function (event) {
  var v = global.v;
  var va = global.va;
  var conductorSuper = global.conductorSuper;

  for (var i = 0; i < MY_GT_MATERIALS.length; i++) {
    var row = MY_GT_MATERIALS[i];
    var id = row[0];
    var symbol = row[1]; // unused but kept
    var color = row[2];
    var tierRaw = row.length >= 6 ? row[5] : null;
    var tier = normTier(tierRaw);

    // tierなし → 通常アイテム型
    if (!tier) {
      var mat = event.create(id)
        .element(id)
        .color(color)
        .iconSet(GTMaterialIconSet.METALLIC)
        .ingot()
        .dust();
      // flags は varargs なので apply で渡す（スプレッド禁止）
      mat.flags.apply(mat, COMMON_FLAGS);

      mat.fluid();
      continue;
    }

    // tierあり → ケーブル型（条件満たさなければスキップ＋ログ）
    if (!VALID_TIERS[tier]) {
      console.info("[materials] skip cable '" + id + "': invalid tier='" + tierRaw + "' (allowed: ULV..MAX)");
      continue;
    }
    if (typeof conductorSuper !== 'function') {
      console.info("[materials] skip cable '" + id + "': global.conductorSuper missing");
      continue;
    }
    if (!hasTier(v, va, tier)) {
      var haveV = v ? Object.keys(v).join(',') : '(v missing)';
      var haveVa = va ? Object.keys(va).join(',') : '(va missing)';
      console.info("[materials] skip cable '" + id + "': tier '" + tier + "' not found in v/va. v={" + haveV + "} va={" + haveVa + "}");
      continue;
    }

    // スプレッド禁止なので concat で結合
    var wireFlags = COMMON_FLAGS.concat(WIRE_FLAGS_EXTRA);

    conductorSuper(
      event,
      id,
      null,
      color,
      GTMaterialIconSet.BRIGHT,
      [21600, 'highest', va[tier], 4000],
      [v[tier], 128, 0, true],
      wireFlags
    );
  }
});