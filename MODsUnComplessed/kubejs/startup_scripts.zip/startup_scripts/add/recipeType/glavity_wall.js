GTCEuStartupEvents.registry('gtceu:recipe_type', event => {
  event.create('gravity_well')
    .category('gravity_well')
    .setMaxIOSize(3, 1, 3, 1)
})
GTCEuStartupEvents.registry('gtceu:recipe_type', event => {
  event.create('gtneh')
    .category('gtneh')
    .setMaxIOSize(2, 1, 1, 1)
})
