package DIV.gtcsolo.registry;

import com.gregtechceu.gtceu.api.machine.MultiblockMachineDefinition;
import com.gregtechceu.gtceu.api.machine.multiblock.PartAbility;
import com.gregtechceu.gtceu.api.machine.multiblock.WorkableElectricMultiblockMachine;
import com.gregtechceu.gtceu.api.pattern.FactoryBlockPattern;
import com.gregtechceu.gtceu.api.pattern.Predicates;
import com.gregtechceu.gtceu.api.data.RotationState;
import com.gregtechceu.gtceu.api.registry.registrate.GTRegistrate;
import com.gregtechceu.gtceu.common.data.GTRecipeModifiers;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.registries.ForgeRegistries;

import static com.gregtechceu.gtceu.api.pattern.Predicates.*;

public class ModMachines {

    public static final GTRegistrate REGISTRATE = GTRegistrate.create("gtcsolo");

    public static MultiblockMachineDefinition FEC;

    public static void init() {
        FEC = REGISTRATE.multiblock("fec", WorkableElectricMultiblockMachine::new)
                .rotationState(RotationState.NON_Y_AXIS)
                .recipeType(ModRecipeTypes.FEC)
                .recipeModifier(GTRecipeModifiers.OC_PERFECT)
                .appearanceBlock(() -> ForgeRegistries.BLOCKS.getValue(
                        ResourceLocation.fromNamespaceAndPath("gtceu", "sturdy_machine_casing")))
                .pattern(definition -> FactoryBlockPattern.start()
                        .aisle("XXAAAAAXX", "XXXXBXXXX", "XXXXFXXXX", "XXXXFXXXX", "XXXXFXXXX", "XXXXBXXXX", "XXAAAAAXX")
                        .aisle("XAXABAXAX", "XDXBXBXDX", "XDXFXFXDX", "XDXFXFXDX", "XDXFXFXDX", "XDXBXBXDX", "XAXABAXAX")
                        .aisle("AXABBBAXA", "XXBXXXBXX", "XXFXXXFXX", "XXFXXXFXX", "XXFXXXFXX", "XXBXXXBXX", "AXABBBAXA")
                        .aisle("AABBBBBAA", "XBXXEXXBX", "XFXXEXXFX", "XFXXEXXFX", "XFXXEXXFX", "XBXXEXXBX", "AABBBBBAA")
                        .aisle("ABBBBBBBA", "BXXEXEXXB", "FXXEXEXXF", "FXXEXEXXF", "FXXEXEXXF", "BXXEXEXXB", "ABBBBBBBA")
                        .aisle("AABBBBBAA", "XBXXEXXBX", "XFXXEXXFX", "XFXXEXXFX", "XFXXEXXFX", "XBXXEXXBX", "AABBBBBAA")
                        .aisle("AXABBBAXA", "XXBXXXBXX", "XXFXXXFXX", "XXFXXXFXX", "XXFXXXFXX", "XXBXXXBXX", "AXABBBAXA")
                        .aisle("XAXABAXAX", "XDXBXBXDX", "XDXFXFXDX", "XDXFXFXDX", "XDXFXFXDX", "XDXBXBXDX", "XAXABAXAX")
                        .aisle("XXAAYAAXX", "XXXXBXXXX", "XXXXFXXXX", "XXXXFXXXX", "XXXXFXXXX", "XXXXBXXXX", "XXAAAAAXX")
                        // F: tempered_glass (KubeJS原文は typo で "tempred")
                        .where('F', blocks(ForgeRegistries.BLOCKS.getValue(
                                ResourceLocation.fromNamespaceAndPath("gtceu", "tempered_glass"))))
                        // B: clean_machine_casing
                        .where('B', blocks(ForgeRegistries.BLOCKS.getValue(
                                ResourceLocation.fromNamespaceAndPath("gtceu", "clean_machine_casing"))))
                        // D: hsla_steel_frame
                        .where('D', blocks(ForgeRegistries.BLOCKS.getValue(
                                ResourceLocation.fromNamespaceAndPath("gtceu", "hsla_steel_frame"))))
                        // E: 加熱コイル
                        .where('E', heatingCoils())
                        // X: 空気
                        .where('X', air())
                        // A: 自MODのケーシング or ハッチ類
                        .where('A', blocks(ModBlocks.HIGH_STRENGTH_STEEL_CASING.get())
                                .or(autoAbilities(definition.getRecipeTypes()))
                                .or(abilities(PartAbility.MAINTENANCE).setExactLimit(1))
                                .or(abilities(PartAbility.INPUT_ENERGY)
                                        .setMinGlobalLimited(1).setMaxGlobalLimited(2)))
                        // Y: コントローラー本体
                        .where('Y', controller(blocks(definition.getBlock())))
                        .build())
                .workableCasingModel(
                        ResourceLocation.fromNamespaceAndPath("gtcsolo", "block/high_strength_steel_casing"),
                        ResourceLocation.fromNamespaceAndPath("gtceu", "block/multiblock/assembler"))
                .register();
    }
}