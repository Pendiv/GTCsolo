package DIV.gtcsolo.registry;

import com.gregtechceu.gtceu.api.capability.recipe.IO;
import com.gregtechceu.gtceu.api.recipe.GTRecipeType;
import com.gregtechceu.gtceu.api.registry.GTRegistries;
import net.minecraft.resources.ResourceLocation;

public class ModRecipeTypes {

    // fantasy_element_constructor の略
    public static GTRecipeType FEC;

    public static void init() {
        FEC = new GTRecipeType(
                ResourceLocation.fromNamespaceAndPath("gtcsolo", "fec"), "multiblock")
                // アイテム入力6, アイテム出力1, 液体入力1, 液体出力0
                .setMaxIOSize(6, 1, 1, 0)
                .setEUIO(IO.IN);

        GTRegistries.RECIPE_TYPES.register(
                ResourceLocation.fromNamespaceAndPath("gtcsolo", "fec"), FEC);
    }
}